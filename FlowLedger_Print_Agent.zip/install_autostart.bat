@echo off
set "TARGET=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\FlowLedgerPrintAgent.vbs"
(
echo Set fso = CreateObject("Scripting.FileSystemObject"^)
echo currentDir = "%~dp0"
echo Set WshShell = CreateObject("WScript.Shell"^)
echo WshShell.Run "cmd /c node """ ^& currentDir ^& "printer_agent.cjs""", 0, False
) > "%TARGET%"
echo ========================================================
echo Flow Ledger Print Agent Auto-Startup successfully installed!
echo Agent will now start automatically whenever Windows boots.
echo ========================================================
pause
